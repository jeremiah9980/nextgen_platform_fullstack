# Ring + Presence Analytics Platform

This project combines Ring camera motion logs and presence scanning (WiFi and Bluetooth) to track and correlate devices, vehicles, and people entering a cul-de-sac.

...