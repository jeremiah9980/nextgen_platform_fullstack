import time
from bluepy.btle import Scanner

scanner = Scanner()

while True:
    devices = scanner.scan(10.0)
    for dev in devices:
        print(f"Device {dev.addr} ({dev.addrType}), RSSI={dev.rssi} dB")
    time.sleep(20)
