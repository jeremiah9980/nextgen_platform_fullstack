import time, math
from bluepy.btle import Scanner

target_mac = "AA:BB:CC:DD:EE:FF"
scanner = Scanner()

while True:
    devices = scanner.scan(5.0)
    for dev in devices:
        if dev.addr.lower() == target_mac.lower():
            print(f"Beacon {dev.addr} seen with RSSI: {dev.rssi}")
    time.sleep(10)
